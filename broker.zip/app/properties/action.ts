"use server";

import { db } from "@/prisma/db";
import { revalidatePath } from "next/cache";

export async function createArea(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();

  if (!name) {
    throw new Error("Area name is required.");
  }

  const area = await db.orm.public.Area.create({
    name,
  });

  revalidatePath("/properties");

  return {
    id: Number(area.id),
    name: String(area.name),
  };
}

export async function createColony(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const areaId = Number(formData.get("areaId"));

  if (!name) {
    throw new Error("Colony name is required.");
  }

  if (!areaId) {
    throw new Error("Area is required.");
  }

  const colony = await db.orm.public.Colony.create({
    name,
    areaId,
  });

  revalidatePath("/properties");

  return {
    id: Number(colony.id),
    name: String(colony.name),
    areaId: Number(colony.areaId),
  };
}

export async function createWing(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const colonyId = Number(formData.get("colonyId"));

  if (!name) {
    throw new Error("Wing name is required.");
  }

  if (!colonyId) {
    throw new Error("Colony is required.");
  }

  const wing = await db.orm.public.Wing.create({
    name,
    colonyId,
    numberOfFloors: 0,
  });

  revalidatePath("/properties");

  return {
    id: Number(wing.id),
    name: String(wing.name),
    colonyId: Number(wing.colonyId),
  };
}

export async function createFloor(formData: FormData) {
  const floorNumber = Number(formData.get("floorNumber"));
  const numberOfFlats = Number(formData.get("numberOfFlats"));
  const wingId = Number(formData.get("wingId"));

  if (!wingId) {
    throw new Error("Wing is required.");
  }

  if (Number.isNaN(floorNumber)) {
    throw new Error("Floor number is required.");
  }

  if (!numberOfFlats || numberOfFlats < 1) {
    throw new Error("Number of flats must be at least 1.");
  }

  const floor = await db.orm.public.Floor.create({
    floorNumber,
    numberOfFlats,
    wingId,
  });


  revalidatePath("/properties");

  return {
    id: Number(floor.id),
    floorNumber: Number(floor.floorNumber),
    numberOfFlats: Number(floor.numberOfFlats),
    wingId: Number(floor.wingId),
  };
}

export async function createFlat(formData: FormData) {
  const flatNumber = String(formData.get("flatNumber") ?? "").trim();
  const type = String(formData.get("type") ?? "").trim();
  const floorId = Number(formData.get("floorId"));

  if (!flatNumber) {
    throw new Error("Flat number is required.");
  }

  if (!type) {
    throw new Error("Flat type is required.");
  }

  if (!floorId) {
    throw new Error("Floor is required.");
  }

  const flat = await db.orm.public.Flat.create({
    flatNumber,
    type,
    floorId,
  });

  revalidatePath("/properties");

  return {
    id: Number(flat.id),
    flatNumber: String(flat.flatNumber),
    type: String(flat.type),
    floorId: Number(flat.floorId),
  };
}