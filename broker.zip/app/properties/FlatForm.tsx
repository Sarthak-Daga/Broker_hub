"use client";

import { useState } from "react";
import SearchableSelect from "../components/searchableSelect";
import {
  createArea,
  createColony,
  createWing,
  createFloor,
  createFlat,
} from "./action";

type Area = {
  id: number;
  name: string;
};

type Colony = {
  id: number;
  name: string;
  areaId: number;
};

type Wing = {
  id: number;
  name: string;
  colonyId: number;
};

type Floor = {
  id: number;
  wingId: number;
  floorNumber: number;
  numberOfFlats: number;
};

type Flat = {
  id: number;
  floorId: number;
  flatNumber: string;
  type: string;
};

type FlatFormProps = {
  areas: Area[];
  colonies: Colony[];
  wings: Wing[];
  floors: Floor[];
  flats: Flat[];
};

export default function FlatForm({
  areas,
  colonies,
  wings,
  floors,
  flats,
}: FlatFormProps) {
  // --------------------------------------------------
  // Selected hierarchy
  // --------------------------------------------------

  const [areaId, setAreaId] = useState<number | null>(null);
  const [colonyId, setColonyId] = useState<number | null>(null);
  const [wingId, setWingId] = useState<number | null>(null);
  const [floorId, setFloorId] = useState<number | null>(null);
  const [flatId, setFlatId] = useState<number | null>(null);

  // --------------------------------------------------
  // Local copies
  // --------------------------------------------------

  const [localAreas, setLocalAreas] = useState<Area[]>(areas);
  const [localColonies, setLocalColonies] =
    useState<Colony[]>(colonies);
  const [localWings, setLocalWings] = useState<Wing[]>(wings);
  const [localFloors, setLocalFloors] = useState<Floor[]>(floors);
  const [localFlats, setLocalFlats] = useState<Flat[]>(flats);

  // --------------------------------------------------
  // Creation UI state
  // --------------------------------------------------

  const [addingArea, setAddingArea] = useState(false);
  const [addingColony, setAddingColony] = useState(false);
  const [addingWing, setAddingWing] = useState(false);
  const [addingFloor, setAddingFloor] = useState(false);
  const [addingFlat, setAddingFlat] = useState(false);

  const [newAreaName, setNewAreaName] = useState("");
  const [newColonyName, setNewColonyName] = useState("");
  const [newWingName, setNewWingName] = useState("");
  const [newFloorNumber, setNewFloorNumber] = useState("");
  const [newNumberOfFlats, setNewNumberOfFlats] = useState("");
  const [newFlatNumber, setNewFlatNumber] = useState("");
  const [newFlatType, setNewFlatType] = useState("");

  const [creating, setCreating] = useState<
    "area" | "colony" | "wing" | "floor" | "flat" | null
  >(null);

  // --------------------------------------------------
  // Cascading filters
  // --------------------------------------------------

  const filteredColonies = localColonies.filter(
    (colony) => colony.areaId === areaId
  );

  const filteredWings = localWings.filter(
    (wing) => wing.colonyId === colonyId
  );

  const filteredFloors = localFloors.filter(
    (floor) => floor.wingId === wingId
  );

  const filteredFlats = localFlats.filter(
    (flat) => flat.floorId === floorId
  );

  // --------------------------------------------------
  // Create Area
  // --------------------------------------------------

  async function handleCreateArea() {
    if (!newAreaName.trim()) return;

    try {
      setCreating("area");

      const formData = new FormData();
      formData.append("name", newAreaName.trim());

      const area = await createArea(formData);

      setLocalAreas((current) => [...current, area]);
      setAreaId(area.id);

      setColonyId(null);
      setWingId(null);
      setFloorId(null);
      setFlatId(null);

      setNewAreaName("");
      setAddingArea(false);
    } catch (error) {
      console.error(error);
      alert("Failed to create area.");
    } finally {
      setCreating(null);
    }
  }

  // --------------------------------------------------
  // Create Colony
  // --------------------------------------------------

  async function handleCreateColony() {
    if (!areaId || !newColonyName.trim()) return;

    try {
      setCreating("colony");

      const formData = new FormData();
      formData.append("name", newColonyName.trim());
      formData.append("areaId", String(areaId));

      const colony = await createColony(formData);

      setLocalColonies((current) => [...current, colony]);
      setColonyId(colony.id);

      setWingId(null);
      setFloorId(null);
      setFlatId(null);

      setNewColonyName("");
      setAddingColony(false);
    } catch (error) {
      console.error(error);
      alert("Failed to create colony.");
    } finally {
      setCreating(null);
    }
  }

  // --------------------------------------------------
  // Create Wing
  // --------------------------------------------------

  async function handleCreateWing() {
    if (!colonyId || !newWingName.trim()) return;

    try {
      setCreating("wing");

      const formData = new FormData();
      formData.append("name", newWingName.trim());
      formData.append("colonyId", String(colonyId));

      const wing = await createWing(formData);

      setLocalWings((current) => [...current, wing]);
      setWingId(wing.id);

      setFloorId(null);
      setFlatId(null);

      setNewWingName("");
      setAddingWing(false);
    } catch (error) {
      console.error(error);
      alert("Failed to create wing.");
    } finally {
      setCreating(null);
    }
  }

  // --------------------------------------------------
  // Create Floor
  // --------------------------------------------------

  async function handleCreateFloor() {
    if (
      !wingId ||
      newFloorNumber.trim() === "" ||
      !newNumberOfFlats
    ) {
      return;
    }

    try {
      setCreating("floor");

      const formData = new FormData();
      formData.append("wingId", String(wingId));
      formData.append("floorNumber", newFloorNumber);
      formData.append("numberOfFlats", newNumberOfFlats);

      const floor = await createFloor(formData);

      setLocalFloors((current) => [...current, floor]);
      setFloorId(floor.id);

      setFlatId(null);

      setNewFloorNumber("");
      setNewNumberOfFlats("");
      setAddingFloor(false);
    } catch (error) {
      console.error(error);
      alert("Failed to create floor.");
    } finally {
      setCreating(null);
    }
  }

  // --------------------------------------------------
  // Create Flat
  // --------------------------------------------------

  async function handleCreateFlat() {
    if (
      !floorId ||
      !newFlatNumber.trim() ||
      !newFlatType.trim()
    ) {
      return;
    }

    try {
      setCreating("flat");

      const formData = new FormData();
      formData.append("floorId", String(floorId));
      formData.append("flatNumber", newFlatNumber.trim());
      formData.append("type", newFlatType.trim());

      const flat = await createFlat(formData);

      setLocalFlats((current) => [...current, flat]);
      setFlatId(flat.id);

      setNewFlatNumber("");
      setNewFlatType("");
      setAddingFlat(false);
    } catch (error) {
      console.error(error);
      alert("Failed to create flat.");
    } finally {
      setCreating(null);
    }
  }

  return (
    <div className="space-y-5">

      {/* ================================================= */}
      {/* AREA */}
      {/* ================================================= */}

      <div>
        <label className="mb-2 block text-sm font-medium text-slate-300">
          Area
        </label>

        <SearchableSelect
          options={localAreas.map((area) => ({
            id: area.id,
            label: area.name,
          }))}
          value={areaId}
          onChangeAction={(value) => {
            setAreaId(value);
            setColonyId(null);
            setWingId(null);
            setFloorId(null);
            setFlatId(null);
          }}
          placeholder="Search area..."
        />

        <div className="mt-2">
          {!addingArea ? (
            <button
              type="button"
              onClick={() => setAddingArea(true)}
              className="text-sm font-medium text-blue-400 hover:text-blue-300"
            >
              + New Area
            </button>
          ) : (
            <CreationBox
              label="Area name"
              value={newAreaName}
              onChange={setNewAreaName}
              placeholder="e.g. Ahmedabad"
              onCancel={() => {
                setAddingArea(false);
                setNewAreaName("");
              }}
              onCreate={handleCreateArea}
              creating={creating === "area"}
            />
          )}
        </div>
      </div>

      {/* ================================================= */}
      {/* COLONY */}
      {/* ================================================= */}

      <div>
        <label className="mb-2 block text-sm font-medium text-slate-300">
          Colony
        </label>

        <SearchableSelect
          options={filteredColonies.map((colony) => ({
            id: colony.id,
            label: colony.name,
          }))}
          value={colonyId}
          onChangeAction={(value) => {
            setColonyId(value);
            setWingId(null);
            setFloorId(null);
            setFlatId(null);
          }}
          placeholder={
            areaId ? "Search colony..." : "Select an area first"
          }
          disabled={!areaId}
        />

        {areaId && (
          <div className="mt-2">
            {!addingColony ? (
              <button
                type="button"
                onClick={() => setAddingColony(true)}
                className="text-sm font-medium text-blue-400 hover:text-blue-300"
              >
                + New Colony
              </button>
            ) : (
              <CreationBox
                label="Colony name"
                value={newColonyName}
                onChange={setNewColonyName}
                placeholder="e.g. Shantigram"
                onCancel={() => {
                  setAddingColony(false);
                  setNewColonyName("");
                }}
                onCreate={handleCreateColony}
                creating={creating === "colony"}
              />
            )}
          </div>
        )}
      </div>

      {/* ================================================= */}
      {/* WING */}
      {/* ================================================= */}

      <div>
        <label className="mb-2 block text-sm font-medium text-slate-300">
          Wing
        </label>

        <SearchableSelect
          options={filteredWings.map((wing) => ({
            id: wing.id,
            label: wing.name,
          }))}
          value={wingId}
          onChangeAction={(value) => {
            setWingId(value);
            setFloorId(null);
            setFlatId(null);
          }}
          placeholder={
            colonyId ? "Search wing..." : "Select a colony first"
          }
          disabled={!colonyId}
        />

        {colonyId && (
          <div className="mt-2">
            {!addingWing ? (
              <button
                type="button"
                onClick={() => setAddingWing(true)}
                className="text-sm font-medium text-blue-400 hover:text-blue-300"
              >
                + New Wing
              </button>
            ) : (
              <CreationBox
                label="Wing name"
                value={newWingName}
                onChange={setNewWingName}
                placeholder="e.g. A"
                onCancel={() => {
                  setAddingWing(false);
                  setNewWingName("");
                }}
                onCreate={handleCreateWing}
                creating={creating === "wing"}
              />
            )}
          </div>
        )}
      </div>

      {/* ================================================= */}
      {/* FLOOR */}
      {/* ================================================= */}

      <div>
        <label className="mb-2 block text-sm font-medium text-slate-300">
          Floor
        </label>

        <SearchableSelect
          options={filteredFloors.map((floor) => ({
            id: floor.id,
            label: `Floor ${floor.floorNumber}`,
          }))}
          value={floorId}
          onChangeAction={(value) => {
            setFloorId(value);
            setFlatId(null);
          }}
          placeholder={
            wingId ? "Search floor..." : "Select a wing first"
          }
          disabled={!wingId}
        />

        {wingId && (
          <div className="mt-2">
            {!addingFloor ? (
              <button
                type="button"
                onClick={() => setAddingFloor(true)}
                className="text-sm font-medium text-blue-400 hover:text-blue-300"
              >
                + New Floor
              </button>
            ) : (
              <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
                <label className="mb-2 block text-xs font-medium text-slate-400">
                  Floor details
                </label>

                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="number"
                    value={newFloorNumber}
                    onChange={(event) =>
                      setNewFloorNumber(event.target.value)
                    }
                    placeholder="Floor number"
                    className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
                  />

                  <input
                    type="number"
                    min="1"
                    value={newNumberOfFlats}
                    onChange={(event) =>
                      setNewNumberOfFlats(event.target.value)
                    }
                    placeholder="Number of flats"
                    className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
                  />
                </div>

                <div className="mt-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAddingFloor(false);
                      setNewFloorNumber("");
                      setNewNumberOfFlats("");
                    }}
                    className="rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-300 hover:bg-slate-800"
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    disabled={
                      creating === "floor" ||
                      !newFloorNumber ||
                      !newNumberOfFlats
                    }
                    onClick={handleCreateFloor}
                    className="rounded-lg bg-blue-600 px-3 py-2 text-sm font-medium text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {creating === "floor"
                      ? "Creating..."
                      : "Create"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ================================================= */}
      {/* FLAT */}
      {/* ================================================= */}

      <div>
        <label className="mb-2 block text-sm font-medium text-slate-300">
          Flat
        </label>

        <SearchableSelect
          options={filteredFlats.map((flat) => ({
            id: flat.id,
            label: `${flat.flatNumber} · ${flat.type}`,
          }))}
          value={flatId}
          onChangeAction={setFlatId}
          placeholder={
            floorId ? "Search flat..." : "Select a floor first"
          }
          disabled={!floorId}
        />

        {floorId && (
          <div className="mt-2">
            {!addingFlat ? (
              <button
                type="button"
                onClick={() => setAddingFlat(true)}
                className="text-sm font-medium text-blue-400 hover:text-blue-300"
              >
                + New Flat
              </button>
            ) : (
              <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
                <label className="mb-2 block text-xs font-medium text-slate-400">
                  Flat details
                </label>

                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={newFlatNumber}
                    onChange={(event) =>
                      setNewFlatNumber(event.target.value)
                    }
                    placeholder="Flat number"
                    className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
                  />

                  <input
                    type="text"
                    value={newFlatType}
                    onChange={(event) =>
                      setNewFlatType(event.target.value)
                    }
                    placeholder="e.g. 2BHK"
                    className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
                  />
                </div>

                <div className="mt-3 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAddingFlat(false);
                      setNewFlatNumber("");
                      setNewFlatType("");
                    }}
                    className="rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-300 hover:bg-slate-800"
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    disabled={
                      creating === "flat" ||
                      !newFlatNumber.trim() ||
                      !newFlatType.trim()
                    }
                    onClick={handleCreateFlat}
                    className="rounded-lg bg-blue-600 px-3 py-2 text-sm font-medium text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {creating === "flat"
                      ? "Creating..."
                      : "Create"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// =====================================================
// Reusable creation box
// =====================================================

function CreationBox({
  label,
  value,
  onChange,
  placeholder,
  onCancel,
  onCreate,
  creating,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  onCancel: () => void;
  onCreate: () => void;
  creating: boolean;
}) {
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
      <label className="mb-2 block text-xs font-medium text-slate-400">
        {label}
      </label>

      <input
        type="text"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        autoFocus
        className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-sm text-white outline-none placeholder:text-slate-600 focus:border-blue-500"
      />

      <div className="mt-3 flex justify-end gap-2">
        <button
          type="button"
          onClick={onCancel}
          className="rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-300 hover:bg-slate-800"
        >
          Cancel
        </button>

        <button
          type="button"
          disabled={creating || !value.trim()}
          onClick={onCreate}
          className="rounded-lg bg-blue-600 px-3 py-2 text-sm font-medium text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {creating ? "Creating..." : "Create"}
        </button>
      </div>
    </div>
  );
}